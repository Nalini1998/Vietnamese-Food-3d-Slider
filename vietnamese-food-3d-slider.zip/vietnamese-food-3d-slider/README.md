# Vietnamese Food (3d Slider)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/dywoYop/6e514e5b469f7e3c66a20982eaccb760](https://codepen.io/Nalini1998/pen/dywoYop/6e514e5b469f7e3c66a20982eaccb760).

Responsive (sort of?). Uses this technique for smooth transitions on mouse move - https://codepen.io/rachsmith/post/animation-tip-lerp